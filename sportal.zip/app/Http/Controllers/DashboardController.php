<?php

namespace App\Http\Controllers;

use App\Facility;
use App\Helpers\SmsHelper;
use App\Reservation;
use App\User;
use App\Venue;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = \Auth::user();
        if($user->hasRole('super_admin')){
            $total_facilities = Facility::all()->count();
            $total_venues = Venue::all()->count();
            $total_users = User::all()->count();
            $total_reservations = Reservation::all()->count();
            $sms_account_details = SmsHelper::accountDetails();
            $total_sms = $sms_account_details['data']['credit'] ?? 0;
            $total = [
                'facilities' => $total_facilities,
                'venues' => $total_venues,
                'users' => $total_users,
                'reservations' => $total_reservations,
                'sms' => $total_sms
            ];
            return view('dashboard.super-admin', compact('total'));
        } else if($user->hasRole('facility_manager')){
            return view('dashboard.facility-manager');
        }

        return view('dashboard.index');
    }
}
