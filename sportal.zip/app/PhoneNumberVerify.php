<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PhoneNumberVerify extends Model
{
    protected $table = "phone_number_verify";
    protected $primaryKey = "phone_number";
}
