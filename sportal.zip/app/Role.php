<?php

namespace App;

class Role extends \Spatie\Permission\Models\Role
{
    /**
     * Roles
     */
    const ROLE_SUPER_ADMIN = 'super_admin';
    const ROLE_FACILITY_MANAGER = 'facility_manager';
}
