<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.include.user-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo app('translator')->getFromJson('user.reservations'); ?></h3>
                </div>
                <div class="box-body">
                    <?php echo $__env->make('reservation.include.list-reservations', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <?php echo e($reservations->appends(['name' => request('name'), 'email' => request('email')])->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>