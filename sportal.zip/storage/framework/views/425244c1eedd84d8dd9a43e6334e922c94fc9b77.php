<?php echo $__env->make('common.noshow-modal', ['alert' => __('reservation.confirm-noshow')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('common.delete-modal', ['alert' => __('reservation.confirm-delete')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('common.show-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="box-body table-responsive no-padding">
    <table class="table table-hover">
        <tbody><tr>
            <th><?php echo app('translator')->getFromJson('common.name'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.phone-number'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.facility'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.venue'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.date'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.time'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.status'); ?></th>
            <th><?php echo app('translator')->getFromJson('common.actions'); ?></th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($reservation->customer()->name ?? ''); ?></td>
                <td><?php echo e($reservation->customer()->phone_number ?? ''); ?></td>
                <td><?php echo e($reservation->facility()->name()); ?></td>
                <td><?php echo e($reservation->venue()->name()); ?></td>
                <td><?php echo $reservation->date(); ?></td>
                <td><?php echo $reservation->time(); ?></td>
                <td>
                    <?php if($reservation->status == \App\Reservation::RESERVATIONSTATUS_PENDING): ?>
                        <span class="label label-default"><?php echo app('translator')->getFromJson('reservation.status-pending'); ?></span>
                    <?php elseif($reservation->status == \App\Reservation::RESERVATIONSTATUS_APPROVED): ?>
                        <span class="label label-success"><?php echo app('translator')->getFromJson('reservation.status-approved'); ?></span>
                    <?php elseif($reservation->status == \App\Reservation::RESERVATIONSTATUS_HISTORY): ?>
                        <span class="label label-primary"><?php echo app('translator')->getFromJson('reservation.status-history'); ?></span>
                    <?php elseif($reservation->status == \App\Reservation::RESERVATIONSTATUS_CANCELED): ?>
                        <span class="label label-danger"><?php echo app('translator')->getFromJson('reservation.status-canceled'); ?></span>
                    <?php elseif($reservation->status == \App\Reservation::RESERVATIONSTATUS_NO_SHOW): ?>
                        <span class="label label-warning"><?php echo app('translator')->getFromJson('reservation.status-no_show'); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('reservations.show', $reservation->publicId())); ?>" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></a>
                    <?php $disabled = $reservation->status == \App\Reservation::RESERVATIONSTATUS_PENDING || $reservation->status == \App\Reservation::RESERVATIONSTATUS_APPROVED ? "" : "disabled"; ?>
                    <form role="form" style="display: inline" method="POST" action="<?php echo e(route('reservations.destroy', $reservation->publicId())); ?>" id="<?php echo e($reservation->publicId()); ?>" onsubmit="this.preventDefault()">
                        <input type="hidden" value="DELETE" name="_method">
                        <?php echo e(csrf_field()); ?>

                        <button <?php echo e($disabled); ?> data-toggle="modal" title="<?php echo app('translator')->getFromJson('reservation.status-canceled'); ?>" data-target="#deleteModal" type="button" class="btn btn-danger btn-sm" onclick="setDeleteFormId('<?php echo e($reservation->publicId()); ?>')"><i class="fa fa-trash-o"></i></button>
                    </form>
                    <form role="form" style="display: inline" method="POST" action="<?php echo e(route('reservations.noShow', $reservation->publicId())); ?>" id="noshow-<?php echo e($reservation->publicId()); ?>" onsubmit="this.preventDefault()">
                        <input type="hidden" value="PATCH" name="_method">
                        <?php echo e(csrf_field()); ?>

                        <button <?php echo e($disabled); ?> data-toggle="modal" title="<?php echo app('translator')->getFromJson('reservation.status-no_show'); ?>" data-target="#noshowModal" type="button" class="btn btn-warning btn-sm" onclick="setNoShowFormId('<?php echo e($reservation->publicId()); ?>')"><i class="fa fa-times"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5"><?php echo app('translator')->getFromJson('common.no-results'); ?></td>
            </tr>
        <?php endif; ?>
        </tbody></table>
</div><!-- /.box-body -->
