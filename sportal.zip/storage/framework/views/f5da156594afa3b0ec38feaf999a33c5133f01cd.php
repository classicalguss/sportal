<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="google-site-verification" content="c96HlpVn5sCFIAKPmS5XwwImEDsHoZWuJjBBU-Ph0wU" />

    <title><?php echo app('translator')->getFromJson('app.name'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

    <?php if(app()->isLocale('ar')): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/AdminLTE.min.ar.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/custom.ar.css')); ?> ">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/AdminLTE.min.en.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/custom.en.css')); ?> ">
    <?php endif; ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/skin-green.min.css')); ?> ">
    <?php echo $__env->yieldPushContent('styles'); ?>

<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="skin-green sidebar-mini">
<div class="wrapper">
<!-- Header -->
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Sidebar -->
<?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo e(isset($page_title) ? $page_title : __('app.dashboard')); ?>

            <small><?php echo e(isset($page_description) ? $page_description : null); ?></small>
        </h1>
        <!-- You can dynamically generate breadcrumbs here -->
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->getFromJson('app.dashboard'); ?></a></li>
             <li class="active"><?php echo e(isset($page_title) ? $page_title : __('app.dashboard')); ?></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- Your Page Content Here -->
        <?php echo $__env->yieldContent('content'); ?>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<!-- Footer -->
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<!-- Scripts -->
<script src="<?php echo e(asset('js/jQuery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<?php if(app()->isLocale('ar')): ?>
    <script src="<?php echo e(asset('js/app.min.ar.js')); ?>"></script>
<?php else: ?>
    <script src="<?php echo e(asset('js/app.min.en.js')); ?>"></script>
<?php endif; ?>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
