<!-- <footer class="main-footer">
    <div class="pull-right hidden-xs">

    </div>
    <strong>Copyright &copy; 2018 <a href="http://sportal-app.com"><?php echo app('translator')->getFromJson('app.name'); ?></a>.</strong> All rights reserved.
</footer> -->