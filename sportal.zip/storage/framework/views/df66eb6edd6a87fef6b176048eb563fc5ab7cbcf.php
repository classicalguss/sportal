<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo app('translator')->getFromJson('user.update'); ?></h3>
        </div>
        <form role="form" method="POST" action="<?php echo e(route('users.update', $user->publicId())); ?>">
            <input type="hidden" value="PATCH" name="_method">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
                <?php echo $__env->make('common.show-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('user.include.user-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status"><?php echo app('translator')->getFromJson('common.status'); ?></label>
                            <select class="form-control" id="status" name="status">
                                <?php
                                    $status = $user->status ?? old('status') ?? 9;
                                ?>
                                <option value='9' <?php echo e($status == 9 ? 'selected' : ''); ?>><?php echo app('translator')->getFromJson('user.status-unknown'); ?></option>
                                <option value='0' <?php echo e($status == 0 ? 'selected' : ''); ?>><?php echo app('translator')->getFromJson('user.status-new'); ?></option>
                                <option value='1' <?php echo e($status == 1 ? 'selected' : ''); ?>><?php echo app('translator')->getFromJson('user.status-verified'); ?></option>
                                <option value='2' <?php echo e($status == 2 ? 'selected' : ''); ?>><?php echo app('translator')->getFromJson('user.status-blocked'); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('user.update'); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>