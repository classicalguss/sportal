<section class="invoice">
    <div class="row">
        <div class="col-md-6">
            <h2 class="text-center"><?php echo e($user->name); ?></h2>

            <div class="table-responsive margin-bottom">
                <table class="table">
                    <tbody><tr>
                        <th style="width: 50%" class="text-right flip"><?php echo app('translator')->getFromJson('common.email'); ?></th>
                        <td class="text-left flip"><?php echo e($user->email); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right flip"><?php echo app('translator')->getFromJson('common.phone-number'); ?></th>
                        <td class="text-left flip"><?php echo e($user->phone_number); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right flip"><?php echo app('translator')->getFromJson('common.status'); ?></th>
                        <td class="text-left flip"><span class="label label-<?php echo e($user->userStatusColor()); ?>"><?php echo e($user->userStatus()); ?></span></td>
                    </tr>
                    <?php if($user->birth_date): ?>
                    <tr>
                        <th class="text-right flip"><?php echo app('translator')->getFromJson('common.birthday'); ?></th>
                        <td class="text-left flip"><?php echo e($user->birth_date); ?></td>
                    </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row margin-bottom">
                <div class="col-md-offset-3 col-md-6">
                    <?php $user_image = $user->image()->first() ? $user->image()->first()->filename : asset('img/no-image.png') ?>
                    <img class="img-responsive center-block" src="<?php echo e($user_image); ?>">
                </div>
            </div>
        </div>
    </div>
</section>
