<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.delete-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('common.show-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <div class="box-title" style='left:10px'>
                        <form class="form-inline">
                            <div class="form-group">
                                <input type="text" name="name" class="form-control input-sm" placeholder="<?php echo app('translator')->getFromJson('common.name'); ?>" value="<?php echo e(request('name')); ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" name="email" class="form-control input-sm" placeholder="<?php echo app('translator')->getFromJson('common.email'); ?>" value="<?php echo e(request('email')); ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" name="phone_number" class="form-control input-sm" placeholder="<?php echo app('translator')->getFromJson('common.phone-number'); ?>" value="<?php echo e(request('phone_number')); ?>">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-sm"><?php echo app('translator')->getFromJson('common.filter'); ?></button>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default btn-sm"><?php echo app('translator')->getFromJson('common.reset'); ?></a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody><tr>
                            <th><?php echo app('translator')->getFromJson('common.name'); ?></th>
                            <th><?php echo app('translator')->getFromJson('common.email'); ?></th>
                            <th><?php echo app('translator')->getFromJson('common.phone-number'); ?></th>
                            <th><?php echo app('translator')->getFromJson('common.birthday'); ?></th>
                            <th><?php echo app('translator')->getFromJson('common.status'); ?></th>
                            <th><?php echo app('translator')->getFromJson('common.actions'); ?></th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->phone_number); ?></td>
                            <td><?php echo e($user->birth_date); ?></td>
                            <td><span class="label label-<?php echo e($user->userStatusColor()); ?>"><?php echo e($user->userStatus()); ?></span></td>
                            <td>
                                <form role="form" method="POST" action="<?php echo e(route('users.destroy', $user->publicId())); ?>" id="<?php echo e($user->publicId()); ?>" onsubmit="this.preventDefault()">
                                    <input type="hidden" value="DELETE" name="_method">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="btn-group">
                                        <a href="<?php echo e(route('users.show', $user->publicId())); ?>" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></a>
                                        <a href="<?php echo e(route('users.edit', $user->publicId())); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                        <button data-toggle="modal" data-target="#deleteModal" type="button" class="btn btn-danger btn-sm" onclick="setDeleteFormId('<?php echo e($user->publicId()); ?>')"><i class="fa fa-trash-o"></i></button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6"><?php echo app('translator')->getFromJson('common.no-results'); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody></table>
                </div>
            </div>
            <?php echo e($users->appends(['name' => request('name'), 'email' => request('email')])->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>