<aside class="main-sidebar">
    <section class="sidebar">
        <div class="user-panel">
            <div class="pull-left image flip">
                <img src="<?php echo e(asset('img/user-default.png')); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info flip">
                <p><?php echo e(Auth::user()->name); ?></p>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="header"><?php echo app('translator')->getFromJson('app.pages'); ?></li>
            <li class="<?php echo e((Request::is('dashboard') ? 'active' : '')); ?>"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> <span><?php echo app('translator')->getFromJson('app.dashboard'); ?></span></a></li>
            <?php if(auth()->check() && auth()->user()->hasRole('super_admin')): ?>
            <li class="<?php echo e((Request::is('facilities') ? 'active' : '')); ?>"><a href="<?php echo e(route('facilities.index')); ?>"><i class="fa fa-building"></i> <span><?php echo app('translator')->getFromJson('app.facilities'); ?></span></a></li>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('facility_manager')): ?>
            <?php if(count(Auth::user()->facilities()) == 1): ?>
                <?php $facility = Auth::user()->facility() ?>
                <li class="<?php echo e((Request::is('facilities/'.$facility->publicId()) ? 'active' : '')); ?>"><a href="<?php echo e(route('facilities.show', $facility->publicId())); ?>"><i class="fa fa-building"></i> <span><?php echo app('translator')->getFromJson('facility.manage'); ?></span></a></li>
            <?php else: ?>
                <li class="treeview <?php echo e((Request::is(['facilities', 'facilities/*']) ? 'active' : '')); ?>">
                    <a href="#"><i class="fa fa-building"></i> <span><?php echo app('translator')->getFromJson('app.facilities'); ?></span></a>
                    <ul class="treeview-menu">
                        <?php $__currentLoopData = Auth::user()->facilities(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e((Request::is('facilities/'.$facility->publicId()) ? 'active' : '')); ?>"><a href="<?php echo e(route('facilities.show', $facility->publicId())); ?>"><i class="fa fa-circle-o"></i> <span><?php echo e($facility->name()); ?></span></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php endif; ?>
            <li class="<?php echo e((Request::is('reservations') ? 'active' : '')); ?>"><a href="<?php echo e(route('reservations.index')); ?>"><i class="fa fa-calendar"></i> <span><?php echo app('translator')->getFromJson('app.reservations'); ?></span></a></li>
            <li class="<?php echo e((Request::is('recursive') ? 'active' : '')); ?>"><a href="<?php echo e(route('recursive.index')); ?>"><i class="fa fa-undo"></i> <span><?php echo app('translator')->getFromJson('app.recursive'); ?></span></a></li>
            <li class="<?php echo e((Request::is('reservations/list') ? 'active' : '')); ?>"><a href="<?php echo e(route('reservations.list')); ?>"><i class="fa fa-calendar-check-o"></i> <span><?php echo app('translator')->getFromJson('app.reservation-create'); ?></span></a></li>
            <?php if(auth()->check() && auth()->user()->hasRole('super_admin')): ?>
            <li class="<?php echo e((Request::is('admins') ? 'active' : '')); ?>"><a href="<?php echo e(route('admins.index')); ?>"><i class="fa fa-user-secret"></i> <span><?php echo app('translator')->getFromJson('app.admins'); ?></span></a></li>
            <li class="<?php echo e((Request::is('users') ? 'active' : '')); ?>"><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> <span><?php echo app('translator')->getFromJson('app.users'); ?></span></a></li>
            <li class="<?php echo e((Request::is('types') ? 'active' : '')); ?>"><a href="<?php echo e(route('types.index')); ?>"><i class="fa fa-file"></i> <span><?php echo app('translator')->getFromJson('app.venue-types'); ?></span></a></li>
            
            <?php endif; ?>
        </ul>
    </section>
</aside>
