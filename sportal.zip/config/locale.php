<?php

return [
    'ar' => 'العربية',
    'en' => 'English'
];