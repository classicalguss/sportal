@extends('layouts.app')

@section('content')
    @include('dashboard.include.total-widgets')
@endsection
