<?php 

return [
    'title' => 'اذارة مواعيد الحجز',
    'updated' => 'تم تعديل موعد حجز بنجاح',
    'status-available' => 'متوفر',
    'status-reserved' => 'محجوز',
    'not-found' => 'لا يوجد موعد حجز',
    'update' => 'تعديل موعد حجز'
];