<?php

return [
    'title' => 'سجل الرسائل',
];