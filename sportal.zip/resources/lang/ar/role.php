<?php

return [
    'select' => 'اختر صلاحية',
    'super_admin' => 'مدير النظام',
    'facility_manager' => 'مدير منشأة',
];