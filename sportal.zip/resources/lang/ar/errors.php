<?php 

return [
    'cityId-not-correct' => 'لم يتم اختيار المدينة.',
    'type-not-correct' => 'لم يتم اختيار نوع الملعب.',
    'no-valid-venue-availability-times' => 'Venue Availability Times have invalid data'
];