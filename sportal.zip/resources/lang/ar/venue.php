<?php 

return [
    'title' => 'ادارة الملاعب',
    'indoor' => 'داخلي',
    'outdoor' => 'خارجي',
    'create' => 'انشاء ملعب',
    'create-multi' => 'جمع الملاعب',
    'created' => 'تم انشاء ملعب بنجاح',
    'update' => 'تعديل الملعب',
    'update-availabilities' => 'تعدل موعد الحجز',
    'auto-generate' => 'انشاء بشكل آلي',
    'date-start' => 'موعد البداية',
    'date-finish' => 'موعد النهاية',
    'updated' => 'تم تعديل الملعب بنجاح',
    'deleted' => 'تم حذف الملعب بنجاح',
    'availabilities' => 'موعد حجز الملعب',
];