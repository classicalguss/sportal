<?php

return [
    'more-info' => 'المزيد',
    'total-facilities' => 'عدد المنشآت',
    'total-venues' => 'عدد الملاعب',
    'total-users' => 'عدد المستخدمين',
    'total-reservations' => 'عدد الحجوزات',
    'total-sms' => 'عدد الرسائل المتبقة'
];