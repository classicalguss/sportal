<?php 

return [
    'title' => 'ادارة المستخدمين',
    'status-new' => 'جديد',
    'status-verified' => 'موثق',
    'status-blocked' => 'ممنوع',
    'status-unknown' => 'غير معروف',
    'deleted' => 'تم حذف المستخدم بنجاح',
    'updated' => 'تم تعديل المستخدم بنجاح',
    'update' => 'تعديل المستخدم',
    'status-not-found' => 'لا يوجد حالة',
    'info' => 'معلومات المستخدم',
    'reservations' => 'حجوزات المستخدم'
];