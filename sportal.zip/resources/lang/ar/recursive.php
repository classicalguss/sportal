<?php

return [
    'title' => 'إدارة الحجز المكرر',
    'create' => 'إنشار حجز مكرر',
    'reservations' => 'الحجوزات المكررة',
];