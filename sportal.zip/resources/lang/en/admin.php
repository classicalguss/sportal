<?php 

return [
    'title' => 'Manage Admins',
    'create' => 'Create Admin',
    'update' => 'Update Admin',
    'created' => 'New Admin created successfully',
    'updated' => 'Admin updated successfully',
    'deleted' => 'Admin deleted successfully',
    'error_role' => 'Error creating role',
];