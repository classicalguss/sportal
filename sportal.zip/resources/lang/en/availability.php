<?php 

return [
    'title' => 'Manage Venue Availabilities',
    'updated' => 'Availability Update Successfully',
    'status-available' => 'Available',
    'status-reserved' => 'Reserved',
    'not-found' => 'Availability Not Found',
    'update' => 'Update Venue Availabilities',
];