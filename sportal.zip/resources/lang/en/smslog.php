<?php

return [
    'title' => 'SMS Logs',
];