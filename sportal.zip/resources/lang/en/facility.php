<?php 

return [
    'title' => 'Manage Facilities',
    'manage' => 'Manage Facility',
    'create' => 'Create Facility',
    'update' => 'Update Facility',
    'created' => 'New Facility created successfully',
    'updated' => 'Facility updated successfully',
    'deleted' => 'Facility deleted successfully',
    'multi-select' => 'Select Facility/Facilities to manage',
    'select' => 'Select Facility',
];