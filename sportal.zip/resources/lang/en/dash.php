<?php

return [
    'more-info' => 'More Info',
    'total-facilities' => 'Total Facilities',
    'total-venues' => 'Total Venues',
    'total-users' => 'Total User',
    'total-reservations' => 'Total Reservations',
    'total-sms' => 'Total SMS left'
];