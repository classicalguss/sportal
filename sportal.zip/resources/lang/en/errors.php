<?php

return [
    'cityId-not-correct' => 'City Id (cid) provided not correct.',
    'type-not-correct' => 'Venue Type ID not correct.',
    'no-valid-venue-availability-times' => 'Venue Availability Times have invalid data'
];