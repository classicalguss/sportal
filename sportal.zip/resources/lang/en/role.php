<?php

return [
    'select' => 'Select Role',
    'super_admin' => 'Super Admin',
    'facility_manager' => 'Facility Manager',
];