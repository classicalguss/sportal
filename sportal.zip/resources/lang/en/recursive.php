<?php

return [
    'title' => 'Manage Recurring',
    'create' => 'Create Recurring',
    'reservations' => 'Recurring Reservations',
];