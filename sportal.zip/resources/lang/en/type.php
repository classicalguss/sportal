<?php 

return [
    'title' => 'Manage Venue Types',
    'create' => 'Create Venue Type',
    'update' => 'Update Venue Type',
    'created' => 'Venue Type Created Successfully',
    'updated' => 'Venue Type Updated Successfully',
    'deleted' => 'Venue Type Deleted Successfully',
];